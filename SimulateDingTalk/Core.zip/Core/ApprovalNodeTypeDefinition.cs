﻿namespace Core
{
    public class ApprovalNodeTypeDefinition
    {
        public ApprovalNodeType NodeType { get; set; }

        public ApprovalGatewayType? GatewayType { get; set; }

        public ApprovalGatewayDirection? GatewayDirection { get; set; }

        public Dictionary<string, object>? DataProperty { get; set; }
    }

    public enum ApprovalNodeType
    {
        Approval, // 审批节点
        Gateway, // 网关节点
        Start, // 开始节点
        End, // 结束节点
        /// <summary>
        /// 抄送
        /// </summary>
        Cc
    }

    public enum ApprovalGatewayType
    {
        Exclusive, // 排他网关 (XOR)
        Parallel, // 并行网关 (AND)
        Inclusive // 包含网关 (OR)
    }

    // 网关方向
    public enum ApprovalGatewayDirection
    {
        Split, // 分裂
        Join // 汇聚
    }
}
