﻿namespace Core
{
    public class ApprovalFlowDefinition
    {

    }
}
