﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Core
{
    public class ApprovalAction
    {
        public ApprovalActionType ActionType { get; set; }

        public Dictionary<string, object>? DataProperty { get; set; }
    }

    public enum ApprovalActionType
    {
        /// <summary>
        /// 通过
        /// </summary>
        Approval,
        Reject,
        /// <summary>
        /// 转办
        /// </summary>
        Transfer,
        /// <summary>
        /// 加签 - 分为前加签和后加签
        /// </summary>
        AddApprovalNode,
        /// <summary>
        /// 退回
        /// </summary>
        Return,
        /// <summary>
        /// 撤销
        /// </summary>
        Revoke,
        /// <summary>
        /// 终止流程
        /// </summary>
        TerminationFlow,
        /// <summary>
        /// 暂存
        /// </summary>
        TemporaryStorage,
        /// <summary>
        /// 提交
        /// </summary>
        Submit,

    }
}
