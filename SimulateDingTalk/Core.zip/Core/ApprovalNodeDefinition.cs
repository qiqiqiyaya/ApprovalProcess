﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Core
{
    public class ApprovalNodeDefinition
    {
        public ApprovalNodeTypeDefinition TypeDefinition { get; set; }

        public ApproverDefinition ApproverDefinition { get; set; }

        public List<ApprovalAction> Actions { get; set; }
    }
}
